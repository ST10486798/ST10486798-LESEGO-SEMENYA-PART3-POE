/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppoewithwithpart3;

import static com.mycompany.chatapppoewithwithpart3.MessageApp.messageHashes;
import static com.mycompany.chatapppoewithwithpart3.MessageApp.messageIDs;
import static com.mycompany.chatapppoewithwithpart3.MessageApp.sentMessages;
import static java.time.Clock.system;
import static java.time.InstantSource.system;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
public class ChatappPOEwithWithPart3 {

    private static String deleteByHash;
    private static String recipient;
    private static Object id;
    private static Object targetHash;

    public static void main(String[] args) {
        Message msg1 = new Message();
        Message msg2 = new Message();
        
        sentMessages.add(msg1);
        sentMessages.add(msg2);
        
        messageHashes.add("hash1");
        messageHashes.add("hash2");
        
        messageIDs.add("1");
        messageIDs.add("2");
        
  
    
        displaySenderAndRecipients();      
        displayLongestMessage();
        searchByMessageID("1");
        searchByRecipient("Alice");
        deleteByHash("hash1");
        displayReport();
        
    }

    private static void displaySenderAndRecipients() {
        for (Message msg : sentMessages){
            System.out.println("Sender: " + msg.sender);
        }
    }

    private static void displayLongestMessage() {
        Message longest = null;
        for (Message msg : sentMessages){
            if (longest == null ||msg.content.length() > longest.length()){
                longest = msg;
            }
        }
        if (longest !=null){
            System.out.println("Longest Message: " + longest);
        }
    }

    private static void searchByMessageID(String string) {
        for (Message msg : sentMessages){
            if (msg.id.equals(id)){
                System.out.println("Recipient: " + recipient);
            }
        }
        System.out.println("Message ID not found.");
    }

    private static void searchByRecipient(String alice) {
        for (Message msg : sentMessages){
            if (msg.recipient.equals(recipient)){
                
            }
        }
    }

    private static void deleteByHash(String hash1) {
        sentMessages.removeIf(msg -> msg.hash.equals(targetHash));
        System.out.println("Message with hash " + deleteByHash);
    }

    private static void displayReport() {
        for (Message msg : sentMessages){
            System.out.println(msg);
        }
        
        //  Get all sent messages(Test 1)
        System.out.println("Get all sent message");
        List<Message> sentMessages = system.getSentMessages();
        System.out.println("Expected: Messages with content 'Did you get the cale?' and 'It is dinner time !!'");
        sentMessages.forEach(System.out::println);
        System.out.println();

        // Find the longest message(Test 2)
        System.out.println("=== TEST 2: Find the longest message ===");
        Message longestMessage = system.getLongestMessage();
        System.out.println("Expected: 'Where are you? You are late! I have asked you to be on time.'");
        System.out.println("Actual: " + (longestMessage != null ? longestMessage.getContent() : "No messages found"));
        System.out.println();

        // Search by developer ID(Test 3)
        System.out.println("Search by developer ID");
        Message devMessage = system.searchByDeveloperId("C8 38884567");
        System.out.println("Expected: Message with developer 'C8 38884567' and content 'It is dinner time !!'");
        System.out.println("Actual: " + devMessage);
        System.out.println();

        // Search by recipient(Test 4)
        System.out.println("Search by recipient (+278 38884567)");
        List<Message> recipientMessages = system.searchByRecipient("+278 38884567");
        System.out.println("Expected: 2 messages (one stored, one sent if any)");
        recipientMessages.forEach(System.out::println);
        System.out.println();

        //  Delete a message(Test 5)
        System.out.println("Delete a message");
        String contentToDelete = "Where are you? You are late! I have asked you to be on time.";
        boolean deleted = system.deleteMessage(contentToDelete);
        System.out.println("Deleted message with content: '" + contentToDelete + "'");
        System.out.println("Success: " + deleted);
        System.out.println("Remaining messages count: " + system.messageDatabase.size());
        System.out.println();

        // Generate sent messages report(Test 6)
        System.out.println("Generate sent messages report ");
        system.generateSentMessagesReport();
    }
}
