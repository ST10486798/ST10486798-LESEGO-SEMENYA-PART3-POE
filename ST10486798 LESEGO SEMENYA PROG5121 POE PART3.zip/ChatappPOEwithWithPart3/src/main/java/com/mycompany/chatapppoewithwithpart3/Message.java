/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppoewithwithpart3;

/**
 *
 * @author RC_Student_lab
 */
public class Message {
    String id;
    String sender;
    String recipient;       
    String content;
    String hash;      

    public Message(String id, String sender, String recipient, String content, String hash) {
        this.id = id;
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;
        this.hash = hash;   
    } 

    Message() {
        
    }
    @Override
    public String toString(){
        return "ID: " + id + ", Sender: " + sender + ", Content: " + content + ", Hash: " + hash;
    }

    int length() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getContent() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
