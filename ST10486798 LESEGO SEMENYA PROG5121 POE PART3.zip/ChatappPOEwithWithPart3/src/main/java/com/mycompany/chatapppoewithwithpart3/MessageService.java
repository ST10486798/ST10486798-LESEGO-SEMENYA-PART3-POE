/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppoewithwithpart3;

import java.util.ArrayList;

/**
 *
 * @author RC_Student_lab
 */
public class MessageService {
    public ArrayList<Message> sentMessages = new ArrayList<>();
    private Object id;
    
    
    public void addMessage(Message message){
        sentMessages.add(message);
    }
    
    public ArrayList<Message> getSentMessages(){
    return sentMessages;
    }
    
public String getLongestMessage(){
    Message longest = null;
    for (Message m : sentMessages){
        if (longest == null || m.content.length() ==0){
        }
    }
return longest != null ? longest.content : null;
}



public String findMessageRecipientById(String id){
for (Message m : sentMessages){
    if (m.id.equals(id)){
        return m.recipient;
    }
}
    return null;
    }
}

