/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppoewithwithpart3;

import java.util.ArrayList;

/**
 *
 * @author RC_Student_lab
 */
public class MessageApp {
    static ArrayList<Message> sentMessages = new ArrayList();
    static ArrayList<Message> disregardedMessages = new ArrayList();
    static ArrayList<Message> storedMessages = new ArrayList();
    static ArrayList<String> messageHashes = new ArrayList();
    static ArrayList<String> messageIDs = new ArrayList();
    
}
