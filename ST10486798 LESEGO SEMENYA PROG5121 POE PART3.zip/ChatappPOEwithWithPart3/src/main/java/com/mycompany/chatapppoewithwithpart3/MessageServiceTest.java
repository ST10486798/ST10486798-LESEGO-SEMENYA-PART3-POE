/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppoewithwithpart3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
public class MessageServiceTest {
 
    
    public static class Message {
        private String recipient;
        private String developer;
        private String message;
        private String flag;
        
        public Message(String recipient, String developer, String message, String flag) {
            this.recipient = recipient;
            this.developer = developer;
            this.message = message;
            this.flag = flag;
        }
        
        public String getRecipient() {
            return recipient;
        }
        
        public String getDeveloper() {
            return developer;
        }
        
        public String getMessage() {
            return message;
        }
        
        public String getFlag() {
            return flag;
        }
    }
    
    public static void main(String[] args) {
        // Create test messages
        List<Message> messages = new ArrayList<>();
        messages.add(new Message("+27834557896", null, "Did you get the cake?", "Sent"));
        messages.add(new Message("+27838884567", null, "Where are you? You are late! I have asked you to be on time.", "Stored"));
        messages.add(new Message("+27834484567", null, "Yohoooo, I am at your gate.", "Disregard"));
        messages.add(new Message(null, "0838884567", "It is dinnertime!", "Sent"));
        messages.add(new Message("+27838884567", null, "Ok, I am leaving without you.", "Stored"));
        
        // Test 1: Sent Messages array correctly populated
        System.out.println("Test 1: Sent Messages array correctly populated");
        List<String> sentMessages = getSentMessages(messages);
        System.out.println("Expected: \"Did you get the cake?\" \"It is dinnertime!\"");
        System.out.println("Actual: " + sentMessages);
        System.out.println();
        
        // Test 2: Display the longest Message
        System.out.println("Test 2: Display the longest Message");
        String longestMessage = getLongestMessage(messages);
        System.out.println("Expected: \"Where are you? You are late! I have asked you to be on time.\"");
        System.out.println("Actual: \"" + longestMessage + "\"");
        System.out.println();
        
        // Test 3: Search for messageID
        System.out.println("Test 3: Search for messageID");
        String developerId = "0838884567";
        Message foundMessage = findMessageByDeveloper(messages, developerId);
        System.out.println("Expected: \"0838884567\"");
        System.out.println("Actual: \"" + (foundMessage != null ? foundMessage.getDeveloper() : "Not found") + "\"");
    }
    
    // Helper method to get all sent messages
    public static List<String> getSentMessages(List<Message> messages) {
        List<String> sentMessages = new ArrayList<>();
        for (Message msg : messages) {
            if ("Sent".equals(msg.getFlag())) {
                sentMessages.add(msg.getMessage());
            }
        }
        return sentMessages;
    }
    
    // Helper method to find the longest message
    public static String getLongestMessage(List<Message> messages) {
        String longest = "";
        for (Message msg : messages) {
            if (msg.getMessage().length() > longest.length()) {
                longest = msg.getMessage();
            }
        }
        return longest;
    }
    
    // Helper method to find message by developer ID
    public static Message findMessageByDeveloper(List<Message> messages, String developerId) {
        for (Message msg : messages) {
            if (developerId.equals(msg.getDeveloper())) {
                return msg;
            }
        }
        return null;
    }

}
