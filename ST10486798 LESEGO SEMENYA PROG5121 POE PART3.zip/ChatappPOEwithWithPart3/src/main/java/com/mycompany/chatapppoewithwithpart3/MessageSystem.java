/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppoewithwithpart3;


import java.util.List;
import static org.junit.Assert.assertNull;
import org.junit.Test;

/**
 *
 * @author RC_Student_lab
 */
public class MessageSystem {



    private MessageSystem system;
    private Object MessageSystem;
   

    
    void setUp() {
        system = new MessageSystem();
    }

    @Test
    void testGetSentMessages() {
        List<MessageSystem.Message> sentMessages = system.getSentMessages();
        
        assertEquals(2, sentMessages.size());
        assertTrue(sentMessages.stream().anyMatch(msg -> 
            "Did you get the cale?".equals(msg.getContent())));
        assertTrue(sentMessages.stream().anyMatch(msg -> 
            "It is dinner time !!".equals(msg.getContent())));
    }

    @Test
    void testGetLongestMessage() {
        MessageSystem.Message longest = system.getLongestMessage();
        
        assertNotNull(longest);
        assertEquals("Where are you? You are late! I have asked you to be on time.", 
                     longest.getContent());
    }

    @Test
    void testSearchByDeveloperId() {
        MessageSystem.Message devMessage = system.searchByDeveloperId("C8 38884567");
        
        assertNotNull(devMessage);
        assertEquals("It is dinner time !!", devMessage.getContent());
        assertEquals("4", devMessage.getMessageId());
    }

    @Test
    void testSearchByDeveloperIdNotFound() {
        MessageSystem.Message devMessage = system.searchByDeveloperId("nonexistent");
        assertNull(devMessage);
    }

    @Test
    void testSearchByRecipient() {
        List<MessageSystem.Message> recipientMessages = 
            system.searchByRecipient("+278 38884567");
        
        assertEquals(2, recipientMessages.size());
        assertTrue(recipientMessages.stream().anyMatch(msg -> 
            "Where are you? You are late! I have asked you to be on time.".equals(msg.getContent())));
        assertTrue(recipientMessages.stream().anyMatch(msg -> 
            "Ok, I am leaving without you.".equals(msg.getContent())));
    }

    @Test
    void testSearchByRecipientExcludesDisregarded() {
        List<MessageSystem.Message> recipientMessages = 
            system.searchByRecipient("+278 34484567");
        
        assertEquals(0, recipientMessages.size()); // Should exclude the "Disregard" message
    }

    @Test
    void testDeleteMessage() {
        String content = "Where are you? You are late! I have asked you to be on time.";
        boolean result = system.deleteMessage(content);
        
        assertTrue(result);
        
            
    }

    @Test
    void testDeleteMessageNotFound() {
        boolean result = system.deleteMessage("Nonexistent message");
        assertFalse(result);
       
    }

    @Test
    void testMessageEqualsAndHashCode() {
        MessageSystem.Message msg1 = new MessageSystem.Message(
            "1", "recipient", "dev", "content", "flag");
        MessageSystem.Message msg2 = new MessageSystem.Message(
            "2", "different", "different", "content", "different");
        
        assertEquals(msg1, msg2);
        assertEquals(msg1.hashCode(), msg2.hashCode());
    }

    @Test
    void testMessageNotEquals() {
        MessageSystem.Message msg1 = new MessageSystem.Message(
            "1", "recipient", "dev", "content1", "flag");
        MessageSystem.Message msg2 = new MessageSystem.Message(
            "1", "recipient", "dev", "content2", "flag");
        
        assertNotEquals(msg1, msg2);
    }

    @Test
    void testMessageToString() {
        MessageSystem.Message msg = new MessageSystem.Message(
            "1", "recipient", "dev", "content", "flag");
        
        String expected = "Message{id=1, recipient=recipient, developer=dev, content='content', flag=flag}";
        assertEquals(expected, msg.toString());
    }

    private void assertNotEquals(Message msg1, Message msg2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean deleteMessage(String nonexistent_message) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private List<Message> getSentMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Message getLongestMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Message searchByDeveloperId(String c8_38884567) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private List<Message> searchByRecipient(String _38884567) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int i, int size) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean anyMatch) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertNotNull(Message longest) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String where_are_you_You_are_late_I_have_asked_y, Object content) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean result) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(Message msg1, Message msg2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class Message {

        public Message() {
        }

        private Message(String string, String recipient, String dev, String content, String flag) {
            
        }

        private Object getContent() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object getMessageId() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private class messageDatabase {

        private static Object size() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static Object stream() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public messageDatabase() {
        }
    }
}